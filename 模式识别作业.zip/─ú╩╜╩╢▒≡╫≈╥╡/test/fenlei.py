import tensorflow as tf
import numpy as np
np.random.seed(1337)  # for reproducibility

import os
import sys
sys.path.append("../models")
sys.path.append("../base")
filename = os.path.basename(__file__)

from cnn import CNN
# from base_func import run_sess
from tensorflow.examples.tutorials.mnist import input_data


# Loading dataset
# 此函数用于读取.txt文件 to make training set/ test set
def txt_train_matrix(filename):
    file = open(filename)
    lines = file.readlines()
    rows = len(lines) #文件行数
    datamat = np.zeros((rows, 1024))
    row = 0
    for line in lines:
        line = line.strip().split('\t')
        datamat[row, :] = line[:]
        row += 1
    return datamat

def txt_test_matrix(filename):
    file = open(filename)
    lines = file.readlines()
    rows = len(lines) #文件行数
    datamat = np.zeros((rows, 1024))
    row = 0
    for line in lines:
        line = line.strip().split('\t')
        datamat[row, :] = line[:]
        row += 1
    return datamat

train_data = txt_train_matrix('../dataset/Test_data/Vibration_sample/train3.txt')
# train_data = np.transpose(train_data)
train_data = train_data.astype(np.float32)
test_data  = txt_test_matrix('../dataset/Test_data/Vibration_sample/test3.txt')
# test_data  = np.transpose(test_data)
test_data = test_data.astype(np.float32)
print("train_data: \n")
# print(train_data)
print(train_data.shape)
print('\n')
print("test_data: \n")
# print(test_data)
print(test_data.shape)
#############################

# make label#################
a = np.zeros((400, 5))
a[0:80, 0] = 1
a[80:160, 1] = 1
a[160:240, 2] = 1
a[240:320, 3] = 1
a[320:400, 4] = 1
# a[300:360, 5] = 1

print(a)
print(a.shape)
print('\n')

b = np.zeros((100, 5))
b[0:20, 0] = 1
b[20:40, 1] = 1
b[40:60, 2] = 1
b[60:80, 3] = 1
b[80:100, 4] = 1
# b[100:120, 5] = 1

print(b)
print(b.shape)
print('\n')
train_label = a.astype(np.float64)
test_label = b.astype(np.float64)
###############################

# Splitting data
datasets = [train_data,train_label,
            test_data , test_label]

x_dim=datasets[0].shape[1]     # 800 * 768
y_dim=datasets[1].shape[1]     # 80 * 4
p_dim=int(np.sqrt(x_dim))
# 8月17日学习######
print(x_dim)
print(y_dim)
print(datasets[0].dtype)
print(datasets[1].dtype)
print(datasets[2].dtype)
print(datasets[3].dtype)
##################
######################################
# # Loading dataset
# # Each datapoint is a 8x8 image of a digit.
# # mnist = input_data.read_data_sets('../dataset/MNIST_data', one_hot=True)
#
# # Splitting data
# datasets = [mnist.train.images,mnist.train.labels,
#             mnist.test.images , mnist.test.labels]
#
# # trX, trY, teX, teY = mnist.train.images, mnist.train.labels,
# # mnist.test.images, mnist.test.labels
#
# x_dim=datasets[0].shape[1]     # 55000 * 784
# y_dim=datasets[1].shape[1]     # 55000 * 10
# p_dim=int(np.sqrt(x_dim))
# # 8月17日学习######
# print(x_dim)
# print(y_dim)
# print(datasets[0].dtype)
# print(datasets[1].dtype)
# print(datasets[2].dtype)
# print(datasets[3].dtype)
# ##################

tf.reset_default_graph()
# Training
Fault = CNN(
             output_act_func='softmax',
             hidden_act_func='relu',
             loss_func='cross_entropy',
             use_for='classification',
             lr=1e-3,
             epochs=100,
             img_shape=[p_dim,p_dim],
             channels=[1, 6, 6, 64, y_dim], # 前几维给 ‘Conv’ ，后几维给 ‘Full connect’
             layer_tp=['C','P','C','P'],
             fsize=[[4,4],[3,3]],
             ksize=[[2,2],[2,2]],
             batch_size=32,
             dropout= 0.65)
# run_sess(classifier,datasets,filename,load_saver='')
# label_distribution = classifier.label_distribution
with tf.Session() as sess:
    train_X, train_Y, test_X, test_Y = datasets
    summ = None
    load_saver=''
    sess.run(tf.global_variables_initializer())
    Fault.train_model(train_X=train_X,
                       train_Y=train_Y,
                       test_X=test_X,
                       test_Y=test_Y,
                       sess=sess,
                       summ=summ,
                       load_saver=load_saver)
    Fault.show_and_save_result(filename)